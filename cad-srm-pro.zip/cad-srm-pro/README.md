# CAD-SRM Pro — Système de Référencement de Modèles

Application SaaS professionnelle de conception assistée par ordinateur, inspirée d'AutoCAD Covadis — spécialisée pour la topographie et l'aménagement du territoire.

## Stack technique

- **Frontend** : Next.js 16 (App Router) + React 19 + TypeScript strict
- **Dessin** : Canvas 2D natif (aucune dépendance lourde)
- **Backend** : Next.js API Routes
- **Base de données** : PostgreSQL + Drizzle ORM
- **Style** : Tailwind CSS v4

## Installation rapide

```bash
# 1. Installer les dépendances
npm install

# 2. Configurer la base de données
cp .env.example .env
# Éditer .env avec vos identifiants PostgreSQL

# 3. Créer les tables
npx drizzle-kit push

# 4. (Optionnel) Données de démonstration
npm run db:seed

# 5. Lancer en développement
npm run dev
```

Ouvrir http://localhost:3000

## Fonctionnalités de l'éditeur

### Outils de dessin
| Outil | Raccourci | Description |
|-------|-----------|-------------|
| Sélection | Esc | Sélectionner et inspecter |
| Ligne | L | Ligne droite (2 clics) |
| Polyligne | P | Ligne brisée (double-clic pour terminer) |
| Polygone | G | Polygone fermé avec remplissage |
| Cercle | C | Cercle (centre + rayon) |
| Rectangle | R | Rectangle (2 coins) |
| Texte | T | Annotation textuelle |
| Mesure | M | Mesure de distance en temps réel |
| Panoramique | Espace | Déplacer la vue |

### Navigation
- **Molette** : Zoom centré sur le curseur
- **Clic molette** : Panoramique
- **Ctrl+Z** : Annuler
- **Del** : Supprimer l'élément sélectionné
- **Ctrl+S** : Sauvegarder

### Calques
- Création de calques nommés avec couleur personnalisée
- Basculement visibilité / verrouillage
- Chaque élément est associé à un calque

### Propriétés des éléments
- Couleur et épaisseur de trait
- Couleur et opacité de remplissage
- Style de ligne (continu, tirets, pointillés)
- Informations géométriques (longueur, superficie, rayon…)

### Bibliothèque de symboles
16 symboles topographiques prêts à l'emploi :
- Géodésie : points géodésiques, bornes, stations, repères NGF
- Hydraulique : puits, regards
- Voirie : croisements
- Réseaux : poteaux électriques, coffrets
- Végétation : arbres
- Géotechnique : sondages

## Structure de la base de données

```sql
projects         — Projets avec paramètres (unités, grille, système de coord.)
layers           — Calques d'un projet (couleur, visibilité, verrouillage)
drawing_elements — Éléments de dessin (géométrie en JSONB, style)
symbols          — Bibliothèque de symboles (statique via API)
```

## API REST

```
GET    /api/projects              — Liste des projets
POST   /api/projects              — Créer un projet (+ 4 calques par défaut)
GET    /api/projects/:id          — Détails d'un projet
PATCH  /api/projects/:id          — Modifier un projet
DELETE /api/projects/:id          — Supprimer (cascade)

GET    /api/projects/:id/layers   — Calques d'un projet
POST   /api/projects/:id/layers   — Créer un calque
PATCH  /api/layers/:id            — Modifier un calque
DELETE /api/layers/:id            — Supprimer un calque (cascade éléments)

GET    /api/projects/:id/elements — Tous les éléments d'un projet
GET    /api/layers/:id/elements   — Éléments d'un calque
POST   /api/layers/:id/elements   — Ajouter un élément
PATCH  /api/elements/:id          — Modifier un élément
DELETE /api/elements/:id          — Supprimer un élément

GET    /api/symbols               — Bibliothèque de symboles
```

## Architecture du projet

```
src/
├── app/
│   ├── api/
│   │   ├── projects/[id]/
│   │   │   ├── layers/      — GET, POST calques
│   │   │   └── elements/    — GET tous éléments
│   │   ├── layers/[id]/
│   │   │   └── elements/    — GET, POST éléments d'un calque
│   │   ├── elements/[id]/   — PATCH, DELETE
│   │   └── symbols/         — GET bibliothèque
│   ├── editor/[id]/         — Éditeur CAD
│   ├── layout.tsx
│   ├── page.tsx             — Dashboard projets
│   └── globals.css
├── components/
│   ├── CADCanvas.tsx        — Moteur de dessin Canvas 2D
│   ├── Toolbar.tsx          — Barre d'outils
│   ├── LayersPanel.tsx      — Panneau calques
│   ├── PropertiesPanel.tsx  — Panneau propriétés
│   ├── SymbolsPanel.tsx     — Bibliothèque symboles
│   └── StatusBar.tsx        — Barre d'état
├── db/
│   ├── schema.ts            — Schéma Drizzle
│   └── index.ts             — Client DB
├── scripts/
│   └── seed.ts              — Données de démo
└── types/
    └── index.ts             — Types TypeScript partagés
```

## Cas d'usage professionnels

- **Topographie** : levés, points géodésiques, altimétrie
- **Aménagement du territoire** : plans de masse, lotissements, zones
- **VRD** : voirie, réseaux divers, assainissement
- **Génie civil** : tracés routiers, ouvrages d'art

---

**CAD-SRM Pro** — Conception professionnelle pour l'aménagement du territoire 🗺️
