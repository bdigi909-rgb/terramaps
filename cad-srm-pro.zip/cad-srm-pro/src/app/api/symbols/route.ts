import { NextResponse } from 'next/server';

// Static topographic symbol library
const SYMBOLS = [
  { id: 1, name: 'Point géodésique', category: 'Géodésie', sym: '△', description: 'Point de triangulation géodésique' },
  { id: 2, name: 'Station', category: 'Géodésie', sym: '⊕', description: 'Station de mesure' },
  { id: 3, name: 'Borne', category: 'Géodésie', sym: '●', description: 'Borne cadastrale ou de délimitation' },
  { id: 4, name: 'Repère NGF', category: 'Géodésie', sym: '⊞', description: 'Repère de nivellement général de la France' },
  { id: 5, name: 'Puits', category: 'Hydraulique', sym: '◎', description: 'Puits ou forage' },
  { id: 6, name: 'Regard', category: 'Hydraulique', sym: '⊙', description: 'Regard de réseau' },
  { id: 7, name: 'Croisement voirie', category: 'Voirie', sym: '✕', description: 'Intersection routière' },
  { id: 8, name: 'Bâtiment', category: 'Urbain', sym: '⬡', description: 'Emprise de bâtiment' },
  { id: 9, name: 'Sondage', category: 'Géotechnique', sym: '◈', description: 'Point de sondage géotechnique' },
  { id: 10, name: 'Cible', category: 'Géodésie', sym: '⌖', description: 'Cible de mesure topographique' },
  { id: 11, name: 'Poteau électrique', category: 'Réseaux', sym: '◇', description: 'Poteau de réseau électrique' },
  { id: 12, name: 'Coffret', category: 'Réseaux', sym: '⊡', description: 'Coffret technique' },
  { id: 13, name: 'Arbre', category: 'Végétation', sym: '⊗', description: 'Arbre isolé' },
];

export async function GET() {
  return NextResponse.json(SYMBOLS);
}
