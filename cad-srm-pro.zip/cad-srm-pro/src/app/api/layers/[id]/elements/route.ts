import { NextResponse } from 'next/server';
import { db } from '@/db';
import { drawingElements } from '@/db/schema';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: Ctx) {
  const { id } = await params;
  const { eq } = await import('drizzle-orm');
  const elements = await db.select().from(drawingElements).where(eq(drawingElements.layerId, Number(id)));
  const mapped = elements.map(el => ({
    id: el.id,
    layerId: el.layerId,
    type: el.type,
    stroke: el.stroke,
    fill: el.fill,
    width: el.width,
    opacity: el.opacity,
    linestyle: el.linestyle,
    ...el.geometry,
  }));
  return NextResponse.json(mapped);
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json();
  const { type, stroke, fill, width, opacity, linestyle, layerId: _layerId, id: _id, ...geometry } = body;

  if (!type) return NextResponse.json({ error: 'Type required' }, { status: 400 });

  const [el] = await db.insert(drawingElements).values({
    layerId: Number(id),
    type,
    geometry,
    stroke: stroke ?? '#58a6ff',
    fill: fill ?? null,
    width: width ?? 1.5,
    opacity: opacity ?? 20,
    linestyle: linestyle ?? 'solid',
  }).returning();

  return NextResponse.json(el, { status: 201 });
}
