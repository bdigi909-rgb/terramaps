import { NextResponse } from 'next/server';
import { db } from '@/db';
import { layers } from '@/db/schema';
import { eq } from 'drizzle-orm';

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json();
  const update: Partial<typeof layers.$inferInsert> = {};
  if (body.name !== undefined) update.name = body.name;
  if (body.color !== undefined) update.color = body.color;
  if (body.visible !== undefined) update.visible = body.visible;
  if (body.locked !== undefined) update.locked = body.locked;
  if (body.order !== undefined) update.order = body.order;

  const [updated] = await db.update(layers).set(update).where(eq(layers.id, Number(id))).returning();
  return NextResponse.json(updated);
}

export async function DELETE(_: Request, { params }: Ctx) {
  const { id } = await params;
  await db.delete(layers).where(eq(layers.id, Number(id)));
  return NextResponse.json({ ok: true });
}
