import { NextResponse } from 'next/server';
import { db } from '@/db';
import { projects } from '@/db/schema';
import { desc } from 'drizzle-orm';

export async function GET() {
  try {
    const all = await db.select().from(projects).orderBy(desc(projects.updatedAt));
    return NextResponse.json(all);
  } catch (e) {
    return NextResponse.json({ error: 'DB error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, description, settings } = body;
    if (!name?.trim()) return NextResponse.json({ error: 'Name required' }, { status: 400 });

    const [project] = await db.insert(projects).values({
      name: name.trim(),
      description: description?.trim() ?? null,
      settings: settings ?? {
        units: 'meters',
        gridSize: 1,
        coordinateSystem: 'Lambert93',
        scale: 1000,
      },
    }).returning();

    // Create default layers
    const { layers } = await import('@/db/schema');
    await db.insert(layers).values([
      { projectId: project.id, name: 'Contours', color: '#58a6ff', order: 0 },
      { projectId: project.id, name: 'Bâtiments', color: '#3fb950', order: 1 },
      { projectId: project.id, name: 'Voirie', color: '#e3b341', order: 2 },
      { projectId: project.id, name: 'Annotations', color: '#a371f7', order: 3 },
    ]);

    return NextResponse.json(project, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'DB error' }, { status: 500 });
  }
}
