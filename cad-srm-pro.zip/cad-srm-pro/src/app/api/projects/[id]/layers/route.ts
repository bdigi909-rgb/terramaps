import { NextResponse } from 'next/server';
import { db } from '@/db';
import { layers } from '@/db/schema';
import { eq, asc } from 'drizzle-orm';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: Ctx) {
  const { id } = await params;
  const all = await db.select().from(layers).where(eq(layers.projectId, Number(id))).orderBy(asc(layers.order));
  return NextResponse.json(all);
}

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json();
  const { name, color } = body;
  if (!name?.trim()) return NextResponse.json({ error: 'Name required' }, { status: 400 });

  const existing = await db.select().from(layers).where(eq(layers.projectId, Number(id)));
  const [layer] = await db.insert(layers).values({
    projectId: Number(id),
    name: name.trim(),
    color: color ?? '#58a6ff',
    visible: true,
    locked: false,
    order: existing.length,
  }).returning();

  return NextResponse.json(layer, { status: 201 });
}
