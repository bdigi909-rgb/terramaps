import { NextResponse } from 'next/server';
import { db } from '@/db';
import { projects } from '@/db/schema';
import { eq } from 'drizzle-orm';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: Ctx) {
  const { id } = await params;
  const [project] = await db.select().from(projects).where(eq(projects.id, Number(id)));
  if (!project) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json(project);
}

export async function PATCH(req: Request, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json();
  const { name, description, settings } = body;
  const update: Partial<typeof projects.$inferInsert> = {
    updatedAt: new Date(),
  };
  if (name !== undefined) update.name = name;
  if (description !== undefined) update.description = description;
  if (settings !== undefined) update.settings = settings;
  const [updated] = await db.update(projects).set(update).where(eq(projects.id, Number(id))).returning();
  return NextResponse.json(updated);
}

export async function DELETE(_: Request, { params }: Ctx) {
  const { id } = await params;
  await db.delete(projects).where(eq(projects.id, Number(id)));
  return NextResponse.json({ ok: true });
}
