import { NextResponse } from 'next/server';
import { db } from '@/db';
import { drawingElements, layers } from '@/db/schema';
import { eq, inArray } from 'drizzle-orm';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: Ctx) {
  const { id } = await params;
  // Get all layers for this project
  const projectLayers = await db.select({ id: layers.id }).from(layers).where(eq(layers.projectId, Number(id)));
  if (projectLayers.length === 0) return NextResponse.json([]);
  const layerIds = projectLayers.map(l => l.id);
  const elements = await db.select().from(drawingElements).where(inArray(drawingElements.layerId, layerIds));

  // Map to frontend format
  const mapped = elements.map(el => ({
    id: el.id,
    layerId: el.layerId,
    type: el.type,
    stroke: el.stroke ?? '#58a6ff',
    fill: el.fill ?? '#1a2744',
    width: el.width ?? 1.5,
    opacity: el.opacity ?? 20,
    linestyle: el.linestyle ?? 'solid',
    ...el.geometry,
  }));

  return NextResponse.json(mapped);
}
