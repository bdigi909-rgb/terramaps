import { NextResponse } from 'next/server';
import { db } from '@/db';
import { drawingElements } from '@/db/schema';
import { eq } from 'drizzle-orm';

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json();
  const { type, stroke, fill, width, opacity, linestyle, id: _id, layerId: _lid, ...geometry } = body;

  const update: Partial<typeof drawingElements.$inferInsert> = { updatedAt: new Date() };
  if (stroke !== undefined) update.stroke = stroke;
  if (fill !== undefined) update.fill = fill;
  if (width !== undefined) update.width = width;
  if (opacity !== undefined) update.opacity = opacity;
  if (linestyle !== undefined) update.linestyle = linestyle;
  if (Object.keys(geometry).length > 0) update.geometry = geometry;

  const [updated] = await db.update(drawingElements).set(update).where(eq(drawingElements.id, Number(id))).returning();
  return NextResponse.json(updated);
}

export async function DELETE(_: Request, { params }: Ctx) {
  const { id } = await params;
  await db.delete(drawingElements).where(eq(drawingElements.id, Number(id)));
  return NextResponse.json({ ok: true });
}
