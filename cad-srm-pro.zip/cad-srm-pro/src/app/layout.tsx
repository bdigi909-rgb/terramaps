import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'CAD-SRM Pro — Système de Référencement de Modèles',
  description:
    'Application professionnelle de conception assistée par ordinateur pour la topographie et l\'aménagement du territoire.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
