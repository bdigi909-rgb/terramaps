'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import CADCanvas, { type CanvasRef } from '@/components/CADCanvas';
import Toolbar from '@/components/Toolbar';
import LayersPanel from '@/components/LayersPanel';
import PropertiesPanel from '@/components/PropertiesPanel';
import SymbolsPanel, { TOPO_SYMBOLS } from '@/components/SymbolsPanel';
import StatusBar from '@/components/StatusBar';
import type {
  DrawingTool,
  DrawingElementUnion,
  LayerData,
  ElementStyle,
  ProjectData,
  SymbolDef,
} from '@/types';

const DEFAULT_STYLE: ElementStyle = {
  stroke: '#58a6ff',
  fill: '#1a2744',
  width: 1.5,
  opacity: 20,
  linestyle: 'solid',
};

export default function EditorPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = Number(params.id);

  const [project, setProject] = useState<ProjectData | null>(null);
  const [layers, setLayers] = useState<LayerData[]>([]);
  const [elements, setElements] = useState<DrawingElementUnion[]>([]);
  const [tool, setTool] = useState<DrawingTool>('select');
  const [activeLayerId, setActiveLayerId] = useState<number>(0);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [style, setStyle] = useState<ElementStyle>(DEFAULT_STYLE);
  const [activePanel, setActivePanel] = useState<'layers' | 'props' | 'symbols'>('layers');
  const [pendingSymbol, setPendingSymbol] = useState<SymbolDef | null>(null);
  const [coordX, setCoordX] = useState(0);
  const [coordY, setCoordY] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [distance, setDistance] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showTextModal, setShowTextModal] = useState(false);
  const [textContent, setTextContent] = useState('');
  const [textSize, setTextSize] = useState(14);
  const [textPos, setTextPos] = useState({ x: 0, y: 0 });
  const [undoStack, setUndoStack] = useState<DrawingElementUnion[][]>([]);
  const [nextId, setNextId] = useState(1);

  const canvasRef = useRef<CanvasRef>(null);

  // Fetch project data
  useEffect(() => {
    async function load() {
      try {
        const [projRes, layersRes, elemsRes] = await Promise.all([
          fetch(`/api/projects/${projectId}`),
          fetch(`/api/projects/${projectId}/layers`),
          fetch(`/api/projects/${projectId}/elements`),
        ]);
        const proj = await projRes.json();
        const layerData: LayerData[] = await layersRes.json();
        const elemData: DrawingElementUnion[] = await elemsRes.json();
        setProject(proj);
        setLayers(layerData);
        setElements(elemData);
        if (layerData.length > 0) setActiveLayerId(layerData[0].id);
        if (elemData.length > 0) setNextId(Math.max(...elemData.map(e => e.id)) + 1);
      } catch (e) {
        console.error('Load error', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [projectId]);

  // Keyboard shortcuts
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.target as HTMLElement).tagName === 'INPUT' || (e.target as HTMLElement).tagName === 'TEXTAREA') return;
      const map: Record<string, DrawingTool> = {
        l: 'line', c: 'circle', r: 'rect', p: 'polygon', g: 'polygon',
        t: 'text', m: 'measure',
      };
      if (e.key === 'Escape') { setTool('select'); setPendingSymbol(null); }
      else if (map[e.key.toLowerCase()]) setTool(map[e.key.toLowerCase()]);
      else if (e.key === 'Delete' && selectedId) deleteSelected();
      else if (e.ctrlKey && e.key === 'z') undo();
      else if (e.ctrlKey && e.key === 's') { e.preventDefault(); save(); }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, undoStack]);

  const addElement = useCallback((elBase: Omit<DrawingElementUnion, 'id'>) => {
    if (elBase.type === 'text') {
      setTextPos({ x: (elBase as { x: number }).x, y: (elBase as { y: number }).y });
      setShowTextModal(true);
      return;
    }
    setUndoStack(s => [...s.slice(-29), elements]);
    const el = { ...elBase, id: nextId } as DrawingElementUnion;
    setNextId(n => n + 1);
    setElements(prev => [...prev, el]);
    // Persist to DB
    persistElement(el);
  }, [elements, nextId]);

  async function persistElement(el: DrawingElementUnion) {
    try {
      await fetch(`/api/layers/${el.layerId}/elements`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(el),
      });
    } catch (e) {
      console.error('Persist element error', e);
    }
  }

  function addTextElement() {
    if (!textContent.trim()) { setShowTextModal(false); return; }
    const el: DrawingElementUnion = {
      id: nextId,
      type: 'text',
      x: textPos.x, y: textPos.y,
      content: textContent,
      size: textSize,
      layerId: activeLayerId,
      ...style,
    };
    setNextId(n => n + 1);
    setUndoStack(s => [...s.slice(-29), elements]);
    setElements(prev => [...prev, el]);
    persistElement(el);
    setTextContent('');
    setShowTextModal(false);
  }

  function deleteSelected() {
    if (!selectedId) return;
    setUndoStack(s => [...s.slice(-29), elements]);
    setElements(prev => prev.filter(e => e.id !== selectedId));
    setSelectedId(null);
    fetch(`/api/elements/${selectedId}`, { method: 'DELETE' }).catch(console.error);
  }

  function undo() {
    if (undoStack.length === 0) return;
    const prev = undoStack[undoStack.length - 1];
    setUndoStack(s => s.slice(0, -1));
    setElements(prev);
    setSelectedId(null);
  }

  async function save() {
    setSaving(true);
    try {
      await fetch(`/api/projects/${projectId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updatedAt: new Date().toISOString() }),
      });
    } finally {
      setTimeout(() => setSaving(false), 1000);
    }
  }

  function exportJSON() {
    const data = JSON.stringify({ project, layers, elements }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${project?.name ?? 'projet'}.json`;
    a.click();
  }

  function handleSymbolSelect(sym: SymbolDef) {
    setPendingSymbol(sym);
    setTool('symbol_place');
    setActivePanel('layers');
  }

  async function addLayer(name: string, color: string) {
    try {
      const res = await fetch(`/api/projects/${projectId}/layers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, color }),
      });
      const layer: LayerData = await res.json();
      setLayers(prev => [...prev, layer]);
      setActiveLayerId(layer.id);
    } catch (e) {
      console.error(e);
    }
  }

  async function deleteLayer(id: number) {
    if (!confirm('Supprimer ce calque et tous ses éléments ?')) return;
    await fetch(`/api/layers/${id}`, { method: 'DELETE' });
    setLayers(prev => prev.filter(l => l.id !== id));
    setElements(prev => prev.filter(e => e.layerId !== id));
    if (activeLayerId === id && layers.length > 1) {
      setActiveLayerId(layers.find(l => l.id !== id)!.id);
    }
  }

  function toggleLayerVisible(id: number) {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, visible: !l.visible } : l));
    fetch(`/api/layers/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ visible: !layers.find(l => l.id === id)?.visible }),
    }).catch(console.error);
  }

  function toggleLayerLock(id: number) {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, locked: !l.locked } : l));
    fetch(`/api/layers/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ locked: !layers.find(l => l.id === id)?.locked }),
    }).catch(console.error);
  }

  const selectedElement = selectedId ? elements.find(e => e.id === selectedId) ?? null : null;
  const activeLayer = layers.find(l => l.id === activeLayerId);

  if (loading) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0d1117', color: '#8b949e' }}>
        Chargement du projet…
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#0d1117', color: '#c9d1d9' }}>
      {/* Top bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        background: '#161b22',
        borderBottom: '1px solid #30363d',
        height: 40,
        padding: '0 12px',
        gap: 8,
        flexShrink: 0,
      }}>
        <Link href="/" style={{ color: '#58a6ff', textDecoration: 'none', fontSize: 16 }}>⬡</Link>
        <span style={{ color: '#30363d' }}>/</span>
        <span style={{ fontSize: 13, fontWeight: 500, color: '#c9d1d9' }}>{project?.name ?? 'Projet'}</span>
        {project?.settings?.coordinateSystem && (
          <span style={{ fontSize: 11, padding: '2px 8px', background: '#0d2137', color: '#58a6ff', borderRadius: 10 }}>
            {project.settings.coordinateSystem}
          </span>
        )}

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          {pendingSymbol && (
            <span style={{ fontSize: 11, color: '#e3b341', display: 'flex', alignItems: 'center', gap: 4 }}>
              ▸ Placer: {pendingSymbol.label}
              <button onClick={() => { setPendingSymbol(null); setTool('select'); }}
                style={{ background: 'none', border: 'none', color: '#f85149', cursor: 'pointer', fontSize: 13 }}>✕</button>
            </span>
          )}
          <button onClick={exportJSON} style={{ padding: '5px 12px', background: 'transparent', color: '#58a6ff', border: '1px solid #30363d', borderRadius: 5, fontSize: 12, cursor: 'pointer' }}>
            Exporter JSON
          </button>
          <button onClick={save} disabled={saving} style={{ padding: '5px 12px', background: '#238636', color: '#fff', border: 'none', borderRadius: 5, fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>
            {saving ? 'Sauvegardé ✓' : '↑ Sauvegarder'}
          </button>
        </div>
      </div>

      {/* Main area */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Toolbar
          tool={tool}
          onToolChange={t => { setTool(t); setPendingSymbol(null); }}
          onZoomIn={() => canvasRef.current?.zoomIn()}
          onZoomOut={() => canvasRef.current?.zoomOut()}
          onZoomFit={() => canvasRef.current?.zoomFit()}
          onUndo={undo}
          onDelete={deleteSelected}
        />

        <CADCanvas
          ref={canvasRef}
          tool={tool}
          layers={layers}
          activeLayerId={activeLayerId}
          elements={elements}
          selectedId={selectedId}
          style={style}
          pendingSymbol={pendingSymbol}
          onElementAdd={addElement}
          onSelect={setSelectedId}
          onToolChange={t => { setTool(t); setPendingSymbol(null); }}
          onCoordsChange={(x, y) => { setCoordX(x); setCoordY(y); }}
          onZoomChange={setZoom}
          onDistanceChange={setDistance}
        />

        {/* Right panel */}
        <div style={{ width: 210, background: '#161b22', borderLeft: '1px solid #30363d', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
          <div style={{ display: 'flex', borderBottom: '1px solid #30363d' }}>
            {(['layers', 'props', 'symbols'] as const).map(p => (
              <div
                key={p}
                onClick={() => setActivePanel(p)}
                style={{
                  flex: 1,
                  padding: '7px 0',
                  textAlign: 'center',
                  fontSize: 11,
                  cursor: 'pointer',
                  color: activePanel === p ? '#58a6ff' : '#8b949e',
                  borderBottom: activePanel === p ? '2px solid #58a6ff' : '2px solid transparent',
                }}
              >
                {p === 'layers' ? 'Calques' : p === 'props' ? 'Propriétés' : 'Symboles'}
              </div>
            ))}
          </div>

          <div style={{ flex: 1, overflowY: 'auto' }}>
            {activePanel === 'layers' && (
              <LayersPanel
                layers={layers}
                activeLayerId={activeLayerId}
                onLayerSelect={setActiveLayerId}
                onLayerToggleVisible={toggleLayerVisible}
                onLayerToggleLock={toggleLayerLock}
                onLayerAdd={addLayer}
                onLayerDelete={deleteLayer}
              />
            )}
            {activePanel === 'props' && (
              <PropertiesPanel
                style={style}
                onStyleChange={s => setStyle(prev => ({ ...prev, ...s }))}
                selectedElement={selectedElement}
                layers={layers}
              />
            )}
            {activePanel === 'symbols' && (
              <SymbolsPanel
                onSymbolSelect={handleSymbolSelect}
                activeSymbol={pendingSymbol?.label ?? null}
              />
            )}
          </div>
        </div>
      </div>

      <StatusBar
        coordX={coordX}
        coordY={coordY}
        zoom={zoom}
        elementCount={elements.length}
        tool={tool}
        distance={distance}
        activeLayerName={activeLayer?.name ?? '—'}
        gridSize={project?.settings?.gridSize ?? 1}
      />

      {/* Text input modal */}
      {showTextModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
          <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 8, padding: 24, width: 320 }}>
            <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>Ajouter une annotation</div>
            <input
              autoFocus
              value={textContent}
              onChange={e => setTextContent(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') addTextElement(); if (e.key === 'Escape') setShowTextModal(false); }}
              placeholder="Contenu de l'annotation..."
              style={{ width: '100%', background: '#0d1117', border: '1px solid #30363d', borderRadius: 5, color: '#c9d1d9', padding: '8px 10px', fontSize: 13, marginBottom: 10, outline: 'none' }}
            />
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: '#8b949e' }}>Taille (px)</label>
              <input type="number" value={textSize} min={8} max={72} onChange={e => setTextSize(parseInt(e.target.value))}
                style={{ width: 70, background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, color: '#c9d1d9', padding: '4px 8px', fontSize: 12 }} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setShowTextModal(false)} style={{ flex: 1, padding: 7, background: 'transparent', border: '1px solid #30363d', borderRadius: 5, color: '#8b949e', cursor: 'pointer', fontSize: 12 }}>
                Annuler
              </button>
              <button onClick={addTextElement} style={{ flex: 1, padding: 7, background: '#238636', border: 'none', borderRadius: 5, color: '#fff', cursor: 'pointer', fontSize: 12 }}>
                Placer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
