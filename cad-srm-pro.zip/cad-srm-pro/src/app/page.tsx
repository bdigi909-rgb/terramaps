'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import type { ProjectData } from '@/types';

export default function HomePage() {
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchProjects();
  }, []);

  async function fetchProjects() {
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      setProjects(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  async function createProject() {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim(), description: newDesc.trim() }),
      });
      const project = await res.json();
      window.location.href = `/editor/${project.id}`;
    } catch (e) {
      console.error(e);
      setCreating(false);
    }
  }

  async function deleteProject(id: number, e: React.MouseEvent) {
    e.preventDefault();
    if (!confirm('Supprimer ce projet ? Cette action est irréversible.')) return;
    await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    setProjects(p => p.filter(pr => pr.id !== id));
  }

  function formatDate(d: string) {
    return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  return (
    <div style={{ minHeight: '100vh', background: '#0d1117' }}>
      {/* Header */}
      <header style={{
        background: '#161b22',
        borderBottom: '1px solid #30363d',
        padding: '0 24px',
        height: 56,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 20, color: '#58a6ff' }}>⬡</span>
          <span style={{ fontSize: 16, fontWeight: 600, color: '#c9d1d9', letterSpacing: '-0.3px' }}>
            CAD-SRM Pro
          </span>
          <span style={{
            fontSize: 10,
            padding: '2px 8px',
            background: '#0d419d',
            color: '#58a6ff',
            borderRadius: 10,
            fontWeight: 500,
          }}>
            Topographie & Aménagement
          </span>
        </div>
        <button
          onClick={() => setShowModal(true)}
          style={{
            padding: '6px 16px',
            background: '#238636',
            color: '#fff',
            border: 'none',
            borderRadius: 6,
            fontSize: 13,
            fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          + Nouveau projet
        </button>
      </header>

      <main style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px' }}>
        {/* Hero */}
        <div style={{ marginBottom: 40 }}>
          <h1 style={{ fontSize: 28, fontWeight: 600, color: '#c9d1d9', marginBottom: 8 }}>
            Vos projets CAD
          </h1>
          <p style={{ color: '#8b949e', fontSize: 14 }}>
            Dessins topographiques, plans d'aménagement, relevés de terrain — tout en un éditeur professionnel.
          </p>
        </div>

        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 32 }}>
          {[
            { label: 'Projets actifs', value: projects.length, color: '#58a6ff' },
            { label: 'Outils dessin', value: 7, color: '#3fb950' },
            { label: 'Formats export', value: 3, color: '#e3b341' },
            { label: 'Systèmes de coord.', value: 5, color: '#a371f7' },
          ].map(s => (
            <div key={s.label} style={{
              background: '#161b22',
              border: '1px solid #30363d',
              borderRadius: 8,
              padding: '16px 20px',
            }}>
              <div style={{ fontSize: 24, fontWeight: 600, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 12, color: '#8b949e', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Projects grid */}
        {loading ? (
          <div style={{ color: '#8b949e', textAlign: 'center', padding: 60 }}>Chargement…</div>
        ) : projects.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '80px 40px',
            border: '1px dashed #30363d',
            borderRadius: 12,
            color: '#8b949e',
          }}>
            <div style={{ fontSize: 40, marginBottom: 16 }}>⬡</div>
            <div style={{ fontSize: 16, color: '#c9d1d9', marginBottom: 8 }}>Créez votre premier projet</div>
            <div style={{ fontSize: 13, marginBottom: 24 }}>
              Levés topographiques, plans de masse, tracés routiers…
            </div>
            <button
              onClick={() => setShowModal(true)}
              style={{
                padding: '8px 20px',
                background: '#238636',
                color: '#fff',
                border: 'none',
                borderRadius: 6,
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              + Nouveau projet
            </button>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
            {projects.map(p => (
              <Link key={p.id} href={`/editor/${p.id}`} style={{ textDecoration: 'none' }}>
                <div style={{
                  background: '#161b22',
                  border: '1px solid #30363d',
                  borderRadius: 10,
                  padding: '20px',
                  cursor: 'pointer',
                  transition: 'border-color 0.15s',
                }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = '#58a6ff')}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = '#30363d')}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                    <div style={{
                      width: 40,
                      height: 40,
                      background: '#0d1117',
                      border: '1px solid #30363d',
                      borderRadius: 8,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 20,
                      color: '#58a6ff',
                    }}>
                      ⬡
                    </div>
                    <button
                      onClick={e => deleteProject(p.id, e)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: '#484f58',
                        cursor: 'pointer',
                        fontSize: 14,
                        padding: 4,
                      }}
                      title="Supprimer le projet"
                    >
                      ✕
                    </button>
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#c9d1d9', marginBottom: 4 }}>
                    {p.name}
                  </div>
                  {p.description && (
                    <div style={{ fontSize: 12, color: '#8b949e', marginBottom: 10, lineHeight: 1.4 }}>
                      {p.description}
                    </div>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
                    <span style={{ fontSize: 11, color: '#484f58' }}>
                      {formatDate(p.updatedAt)}
                    </span>
                    <span style={{
                      fontSize: 11,
                      padding: '2px 8px',
                      background: '#0a1f0a',
                      color: '#3fb950',
                      borderRadius: 10,
                    }}>
                      {p.settings?.coordinateSystem ?? 'Lambert93'}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>

      {/* Create project modal */}
      {showModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 100,
        }}>
          <div style={{
            background: '#161b22',
            border: '1px solid #30363d',
            borderRadius: 10,
            padding: 28,
            width: 420,
          }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: '#c9d1d9', marginBottom: 20 }}>
              Nouveau projet CAD
            </h2>
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontSize: 12, color: '#8b949e', marginBottom: 6 }}>
                Nom du projet *
              </label>
              <input
                value={newName}
                onChange={e => setNewName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && createProject()}
                placeholder="ex: Levé_Zone_Industrielle_A"
                autoFocus
                style={{
                  width: '100%',
                  background: '#0d1117',
                  border: '1px solid #30363d',
                  borderRadius: 6,
                  color: '#c9d1d9',
                  padding: '8px 12px',
                  fontSize: 13,
                  outline: 'none',
                }}
              />
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontSize: 12, color: '#8b949e', marginBottom: 6 }}>
                Description
              </label>
              <textarea
                value={newDesc}
                onChange={e => setNewDesc(e.target.value)}
                placeholder="ex: Levé topographique pour le projet de lotissement Nord"
                rows={3}
                style={{
                  width: '100%',
                  background: '#0d1117',
                  border: '1px solid #30363d',
                  borderRadius: 6,
                  color: '#c9d1d9',
                  padding: '8px 12px',
                  fontSize: 13,
                  resize: 'vertical',
                  outline: 'none',
                  fontFamily: 'inherit',
                }}
              />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 12, color: '#8b949e', marginBottom: 6 }}>
                Système de coordonnées
              </label>
              <select style={{
                width: '100%',
                background: '#0d1117',
                border: '1px solid #30363d',
                borderRadius: 6,
                color: '#c9d1d9',
                padding: '8px 12px',
                fontSize: 13,
              }}>
                <option>Lambert93</option>
                <option>RGF93</option>
                <option>WGS84</option>
                <option>NTF Paris</option>
                <option>ED50</option>
              </select>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button
                onClick={() => setShowModal(false)}
                style={{
                  flex: 1,
                  padding: '8px',
                  background: 'transparent',
                  border: '1px solid #30363d',
                  borderRadius: 6,
                  color: '#8b949e',
                  cursor: 'pointer',
                  fontSize: 13,
                }}
              >
                Annuler
              </button>
              <button
                onClick={createProject}
                disabled={!newName.trim() || creating}
                style={{
                  flex: 1,
                  padding: '8px',
                  background: newName.trim() ? '#238636' : '#1a2e1a',
                  border: 'none',
                  borderRadius: 6,
                  color: newName.trim() ? '#fff' : '#484f58',
                  cursor: newName.trim() ? 'pointer' : 'not-allowed',
                  fontSize: 13,
                  fontWeight: 500,
                }}
              >
                {creating ? 'Création…' : 'Créer le projet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
