import 'dotenv/config';
import { db } from '../db';
import { projects, layers, drawingElements } from '../db/schema';

async function seed() {
  console.log('🌱 Seeding CAD-SRM Pro database…');

  // Demo project 1
  const [proj1] = await db.insert(projects).values({
    name: 'Levé_Topographique_Zone_A',
    description: 'Levé topographique pour le projet de lotissement Nord — Phase 1',
    settings: { units: 'meters', gridSize: 1, coordinateSystem: 'Lambert93', scale: 500 },
  }).returning();

  const [l1, l2, l3, l4] = await db.insert(layers).values([
    { projectId: proj1.id, name: 'Contours', color: '#58a6ff', order: 0 },
    { projectId: proj1.id, name: 'Bâtiments', color: '#3fb950', order: 1 },
    { projectId: proj1.id, name: 'Voirie', color: '#e3b341', order: 2 },
    { projectId: proj1.id, name: 'Annotations', color: '#a371f7', order: 3 },
  ]).returning();

  await db.insert(drawingElements).values([
    {
      layerId: l1.id,
      type: 'polygon',
      geometry: { points: [{ x: 80, y: 60 }, { x: 280, y: 60 }, { x: 280, y: 200 }, { x: 80, y: 200 }] },
      stroke: '#58a6ff', fill: '#0d2137', width: 2, opacity: 15, linestyle: 'solid',
    },
    {
      layerId: l2.id,
      type: 'rect',
      geometry: { x1: 100, y1: 80, x2: 200, y2: 160 },
      stroke: '#3fb950', fill: '#0a1f0a', width: 1.5, opacity: 20, linestyle: 'solid',
    },
    {
      layerId: l3.id,
      type: 'polyline',
      geometry: { points: [{ x: -100, y: 130 }, { x: 80, y: 130 }, { x: 200, y: 100 }, { x: 400, y: 130 }] },
      stroke: '#e3b341', fill: null, width: 2, opacity: 0, linestyle: 'solid',
    },
    {
      layerId: l4.id,
      type: 'text',
      geometry: { x: -80, y: -40, content: 'Zone A — Levé topographique', size: 14 },
      stroke: '#c9d1d9', fill: null, width: 1, opacity: 0, linestyle: 'solid',
    },
    {
      layerId: l1.id,
      type: 'symbol',
      geometry: { x: 100, y: 70, sym: '△', label: 'Pt. géod.' },
      stroke: '#58a6ff', fill: null, width: 1, opacity: 0, linestyle: 'solid',
    },
    {
      layerId: l1.id,
      type: 'circle',
      geometry: { cx: 180, cy: 130, r: 20 },
      stroke: '#a371f7', fill: '#1a0a37', width: 1.5, opacity: 20, linestyle: 'dashed',
    },
  ]);

  // Demo project 2
  const [proj2] = await db.insert(projects).values({
    name: 'Plan_Masse_Lotissement_Beaumont',
    description: 'Plan de masse pour le permis d\'aménager — Lotissement Beaumont',
    settings: { units: 'meters', gridSize: 0.5, coordinateSystem: 'RGF93', scale: 1000 },
  }).returning();

  await db.insert(layers).values([
    { projectId: proj2.id, name: 'Parcelles', color: '#f85149', order: 0 },
    { projectId: proj2.id, name: 'Réseaux', color: '#39d353', order: 1 },
    { projectId: proj2.id, name: 'Cotes', color: '#ffa657', order: 2 },
  ]);

  console.log('✅ Seed completed! Projects created:', proj1.name, '&', proj2.name);
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
