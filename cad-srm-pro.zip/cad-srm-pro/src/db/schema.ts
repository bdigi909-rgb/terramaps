import { pgTable, serial, text, integer, real, boolean, jsonb, timestamp, varchar } from 'drizzle-orm/pg-core';

export const projects = pgTable('projects', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  settings: jsonb('settings').$type<{
    units: 'meters' | 'feet';
    gridSize: number;
    coordinateSystem: string;
    scale: number;
  }>().default({
    units: 'meters',
    gridSize: 1,
    coordinateSystem: 'Lambert93',
    scale: 1000,
  }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const layers = pgTable('layers', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  color: varchar('color', { length: 7 }).default('#58a6ff').notNull(),
  visible: boolean('visible').default(true).notNull(),
  locked: boolean('locked').default(false).notNull(),
  order: integer('order').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const drawingElements = pgTable('drawing_elements', {
  id: serial('id').primaryKey(),
  layerId: integer('layer_id').references(() => layers.id, { onDelete: 'cascade' }).notNull(),
  type: varchar('type', { length: 50 }).notNull(),
  geometry: jsonb('geometry').notNull(),
  stroke: varchar('stroke', { length: 7 }).default('#58a6ff'),
  fill: varchar('fill', { length: 7 }),
  width: real('width').default(1.5),
  opacity: integer('opacity').default(20),
  linestyle: varchar('linestyle', { length: 20 }).default('solid'),
  label: text('label'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const symbols = pgTable('symbols', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  category: varchar('category', { length: 100 }).notNull(),
  svgData: text('svg_data').notNull(),
  description: text('description'),
});

export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
export type Layer = typeof layers.$inferSelect;
export type NewLayer = typeof layers.$inferInsert;
export type DrawingElement = typeof drawingElements.$inferSelect;
export type NewDrawingElement = typeof drawingElements.$inferInsert;
export type Symbol = typeof symbols.$inferSelect;
