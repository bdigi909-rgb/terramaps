'use client';

import { useRef, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import type {
  DrawingTool,
  DrawingElementUnion,
  LayerData,
  Point,
  ElementStyle,
} from '@/types';

export interface CanvasRef {
  getCanvas: () => HTMLCanvasElement | null;
  zoomIn: () => void;
  zoomOut: () => void;
  zoomFit: () => void;
  getViewState: () => { zoom: number; panX: number; panY: number };
  setViewState: (v: { zoom: number; panX: number; panY: number }) => void;
}

interface Props {
  tool: DrawingTool;
  layers: LayerData[];
  activeLayerId: number;
  elements: DrawingElementUnion[];
  selectedId: number | null;
  style: ElementStyle;
  pendingSymbol: { sym: string; label: string } | null;
  onElementAdd: (el: Omit<DrawingElementUnion, 'id'>) => void;
  onSelect: (id: number | null) => void;
  onToolChange: (tool: DrawingTool) => void;
  onCoordsChange: (x: number, y: number) => void;
  onZoomChange: (zoom: number) => void;
  onDistanceChange: (dist: number | null) => void;
}

const GRID = 20;
const SCALE = 0.5;

function wToS(wx: number, wy: number, panX: number, panY: number, zoom: number) {
  return { x: panX + wx * zoom, y: panY + wy * zoom };
}
function sToW(sx: number, sy: number, panX: number, panY: number, zoom: number) {
  return { x: (sx - panX) / zoom, y: (sy - panY) / zoom };
}
function snapPt(wx: number, wy: number) {
  return { x: Math.round(wx / GRID) * GRID, y: Math.round(wy / GRID) * GRID };
}
function dist2(a: Point, b: Point) {
  return Math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2);
}
function worldDist(a: Point, b: Point) {
  return (dist2(a, b) * SCALE).toFixed(3);
}
function distToSeg(p: Point, a: Point, b: Point) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const l2 = dx * dx + dy * dy;
  if (l2 === 0) return dist2(p, a);
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  return dist2(p, { x: a.x + t * dx, y: a.y + t * dy });
}
function pointInPoly(pt: Point, poly: Point[]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
    if ((yi > pt.y) !== (yj > pt.y) && pt.x < ((xj - xi) * (pt.y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

const CADCanvas = forwardRef<CanvasRef, Props>(function CADCanvas(
  {
    tool, layers, activeLayerId, elements, selectedId, style,
    pendingSymbol, onElementAdd, onSelect, onToolChange,
    onCoordsChange, onZoomChange, onDistanceChange,
  },
  ref
) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const state = useRef({
    zoom: 1,
    panX: 0,
    panY: 0,
    drawing: false,
    points: [] as Point[],
    mouseWorld: { x: 0, y: 0 } as Point,
    isPanning: false,
    panStart: null as Point | null,
    tool,
  });

  useImperativeHandle(ref, () => ({
    getCanvas: () => canvasRef.current,
    zoomIn: () => { state.current.zoom = Math.min(10, state.current.zoom * 1.3); render(); onZoomChange(state.current.zoom); },
    zoomOut: () => { state.current.zoom = Math.max(0.1, state.current.zoom / 1.3); render(); onZoomChange(state.current.zoom); },
    zoomFit: () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      state.current.zoom = 1;
      state.current.panX = canvas.width / 2;
      state.current.panY = canvas.height / 2;
      render();
      onZoomChange(1);
    },
    getViewState: () => ({ zoom: state.current.zoom, panX: state.current.panX, panY: state.current.panY }),
    setViewState: (v) => { state.current.zoom = v.zoom; state.current.panX = v.panX; state.current.panY = v.panY; render(); },
  }));

  // Keep tool ref in sync
  useEffect(() => { state.current.tool = tool; }, [tool]);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { zoom, panX, panY, drawing, points, mouseWorld } = state.current;
    const W = canvas.width, H = canvas.height;

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(0, 0, W, H);

    // Grid
    ctx.strokeStyle = '#1e2530';
    ctx.lineWidth = 0.5;
    const startX = (Math.floor((0 - panX) / zoom / GRID)) * GRID;
    const startY = (Math.floor((0 - panY) / zoom / GRID)) * GRID;
    const endX = (W - panX) / zoom + GRID;
    const endY = (H - panY) / zoom + GRID;
    for (let wx = startX; wx < endX; wx += GRID) {
      const { x } = wToS(wx, 0, panX, panY, zoom);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let wy = startY; wy < endY; wy += GRID) {
      const { y } = wToS(0, wy, panX, panY, zoom);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    ctx.strokeStyle = '#2d3748';
    for (let wx = startX; wx < endX; wx += GRID * 5) {
      const { x } = wToS(wx, 0, panX, panY, zoom);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let wy = startY; wy < endY; wy += GRID * 5) {
      const { y } = wToS(0, wy, panX, panY, zoom);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    // Scale labels
    ctx.fillStyle = '#3d4f6e';
    ctx.font = '9px monospace';
    for (let wx = startX; wx < endX; wx += GRID * 10) {
      const { x } = wToS(wx, 0, panX, panY, zoom);
      ctx.fillText((wx * SCALE).toFixed(0) + 'm', x + 2, 12);
    }

    // Elements
    for (const el of elements) {
      const layer = layers.find(l => l.id === el.layerId);
      if (!layer || !layer.visible) continue;
      drawEl(ctx, el, el.id === selectedId, zoom, panX, panY, layer.color);
    }

    // Preview
    if (drawing && points.length > 0) drawPreview(ctx, points, mouseWorld, state.current.tool, zoom, panX, panY);
  }, [elements, layers, selectedId]);

  useEffect(() => { render(); }, [render]);

  function drawEl(
    ctx: CanvasRenderingContext2D,
    el: DrawingElementUnion,
    sel: boolean,
    zoom: number,
    panX: number,
    panY: number,
    layerColor: string
  ) {
    ctx.save();
    const color = el.stroke || layerColor;
    ctx.strokeStyle = sel ? '#ffd700' : color;
    ctx.lineWidth = (el.width || 1.5);
    if (el.linestyle === 'dashed') ctx.setLineDash([8, 4]);
    else if (el.linestyle === 'dotted') ctx.setLineDash([2, 4]);
    else ctx.setLineDash([]);

    const w2s = (x: number, y: number) => wToS(x, y, panX, panY, zoom);

    if (el.type === 'line') {
      const a = w2s(el.x1, el.y1), b = w2s(el.x2, el.y2);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      if (sel) { drawHandle(ctx, a); drawHandle(ctx, b); }
    } else if (el.type === 'polyline') {
      const pts = el.points.map(p => w2s(p.x, p.y));
      ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
      if (sel) pts.forEach(p => drawHandle(ctx, p));
    } else if (el.type === 'polygon') {
      const pts = el.points.map(p => w2s(p.x, p.y));
      ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.closePath();
      ctx.globalAlpha = (el.opacity || 20) / 100;
      ctx.fillStyle = el.fill || '#1a2744';
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.stroke();
      if (sel) pts.forEach(p => drawHandle(ctx, p));
    } else if (el.type === 'circle') {
      const c = w2s(el.cx, el.cy);
      const r = el.r * zoom;
      ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
      if (el.fill) {
        ctx.globalAlpha = (el.opacity || 20) / 100;
        ctx.fillStyle = el.fill;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.stroke();
      if (sel) { drawHandle(ctx, c); drawHandle(ctx, { x: c.x + r, y: c.y }); }
    } else if (el.type === 'rect') {
      const a = w2s(el.x1, el.y1), b = w2s(el.x2, el.y2);
      const rx = Math.min(a.x, b.x), ry = Math.min(a.y, b.y);
      const rw = Math.abs(b.x - a.x), rh = Math.abs(b.y - a.y);
      ctx.beginPath(); ctx.rect(rx, ry, rw, rh);
      if (el.fill) {
        ctx.globalAlpha = (el.opacity || 20) / 100;
        ctx.fillStyle = el.fill;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.stroke();
      if (sel) [a, b, { x: a.x, y: b.y }, { x: b.x, y: a.y }].forEach(p => drawHandle(ctx, p));
    } else if (el.type === 'text') {
      const p = w2s(el.x, el.y);
      ctx.font = `${(el.size || 14) * zoom}px system-ui, sans-serif`;
      ctx.fillStyle = el.stroke || '#c9d1d9';
      ctx.fillText(el.content, p.x, p.y);
      if (sel) drawHandle(ctx, p);
    } else if (el.type === 'symbol') {
      const p = w2s(el.x, el.y);
      ctx.font = `${20 * zoom}px sans-serif`;
      ctx.fillStyle = color;
      ctx.fillText(el.sym, p.x - 10 * zoom, p.y + 8 * zoom);
      ctx.font = `${9 * zoom}px system-ui`;
      ctx.fillStyle = '#8b949e';
      ctx.fillText(el.label || '', p.x - 12 * zoom, p.y + 20 * zoom);
      if (sel) drawHandle(ctx, p);
    }
    ctx.restore();
  }

  function drawHandle(ctx: CanvasRenderingContext2D, p: Point) {
    ctx.save();
    ctx.setLineDash([]);
    ctx.strokeStyle = '#ffd700';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#0d1117';
    ctx.beginPath(); ctx.rect(p.x - 4, p.y - 4, 8, 8);
    ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  function drawPreview(
    ctx: CanvasRenderingContext2D,
    pts: Point[], mw: Point, currentTool: DrawingTool,
    zoom: number, panX: number, panY: number
  ) {
    const w2s = (x: number, y: number) => wToS(x, y, panX, panY, zoom);
    const m = w2s(mw.x, mw.y);
    ctx.save();
    ctx.strokeStyle = '#58a6ff';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 3]);

    if (currentTool === 'line') {
      const a = w2s(pts[0].x, pts[0].y);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(m.x, m.y); ctx.stroke();
      ctx.setLineDash([]);
      drawHandle(ctx, a);
      ctx.font = '11px monospace'; ctx.fillStyle = '#58a6ff';
      ctx.fillText(worldDist(pts[0], mw) + 'm', m.x + 8, m.y - 4);
    } else if (currentTool === 'polyline' || currentTool === 'polygon') {
      const sPts = [...pts.map(p => w2s(p.x, p.y)), m];
      ctx.beginPath(); ctx.moveTo(sPts[0].x, sPts[0].y);
      for (let i = 1; i < sPts.length; i++) ctx.lineTo(sPts[i].x, sPts[i].y);
      if (currentTool === 'polygon' && pts.length > 1) ctx.closePath();
      ctx.stroke();
    } else if (currentTool === 'circle') {
      const c = w2s(pts[0].x, pts[0].y);
      const r = dist2(c, m);
      ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, Math.PI * 2); ctx.stroke();
      drawHandle(ctx, c);
      ctx.font = '11px monospace'; ctx.fillStyle = '#58a6ff';
      ctx.fillText((r / zoom * SCALE).toFixed(2) + 'm', m.x + 8, m.y - 4);
    } else if (currentTool === 'rect') {
      const a = w2s(pts[0].x, pts[0].y);
      ctx.beginPath(); ctx.rect(a.x, a.y, m.x - a.x, m.y - a.y); ctx.stroke();
      ctx.font = '11px monospace'; ctx.fillStyle = '#58a6ff';
      const ww = (Math.abs(mw.x - pts[0].x) * SCALE).toFixed(1);
      const hh = (Math.abs(mw.y - pts[0].y) * SCALE).toFixed(1);
      ctx.fillText(ww + '×' + hh + 'm', m.x + 4, m.y - 4);
    } else if (currentTool === 'measure' && pts.length >= 1) {
      const a = w2s(pts[0].x, pts[0].y);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(m.x, m.y); ctx.stroke();
      const d = parseFloat(worldDist(pts[0], mw));
      ctx.font = '12px monospace'; ctx.fillStyle = '#e3b341';
      ctx.fillText('⟷ ' + d.toFixed(3) + 'm', (a.x + m.x) / 2 + 4, (a.y + m.y) / 2 - 4);
      drawHandle(ctx, a);
    }

    // Closing circle for poly tools
    if ((currentTool === 'polyline' || currentTool === 'polygon') && pts.length > 0) {
      ctx.save(); ctx.setLineDash([]); ctx.strokeStyle = '#3fb950'; ctx.lineWidth = 1.5;
      const first = w2s(pts[0].x, pts[0].y);
      ctx.beginPath(); ctx.arc(first.x, first.y, 6, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }

  function hitTest(el: DrawingElementUnion, mw: Point, tol: number): boolean {
    if (el.type === 'line') return distToSeg(mw, { x: el.x1, y: el.y1 }, { x: el.x2, y: el.y2 }) < tol;
    if (el.type === 'polyline') {
      for (let i = 0; i < el.points.length - 1; i++)
        if (distToSeg(mw, el.points[i], el.points[i + 1]) < tol) return true;
      return false;
    }
    if (el.type === 'polygon') {
      for (let i = 0; i < el.points.length; i++) {
        const j = (i + 1) % el.points.length;
        if (distToSeg(mw, el.points[i], el.points[j]) < tol) return true;
      }
      return pointInPoly(mw, el.points);
    }
    if (el.type === 'circle') return Math.abs(dist2(mw, { x: el.cx, y: el.cy }) - el.r) < tol;
    if (el.type === 'rect') {
      const x1 = Math.min(el.x1, el.x2), x2 = Math.max(el.x1, el.x2);
      const y1 = Math.min(el.y1, el.y2), y2 = Math.max(el.y1, el.y2);
      return mw.x >= x1 - tol && mw.x <= x2 + tol && mw.y >= y1 - tol && mw.y <= y2 + tol;
    }
    if (el.type === 'text' || el.type === 'symbol') return dist2(mw, { x: el.x, y: el.y }) < 20;
    return false;
  }

  // Mouse handlers
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    function getSnap(e: MouseEvent): Point {
      const rect = canvas!.getBoundingClientRect();
      const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
      const { zoom, panX, panY } = state.current;
      const w = sToW(sx, sy, panX, panY, zoom);
      return snapPt(w.x, w.y);
    }

    function onMouseMove(e: MouseEvent) {
      const rect = canvas!.getBoundingClientRect();
      const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
      const s = state.current;

      if (s.isPanning && s.panStart) {
        s.panX += sx - s.panStart.x;
        s.panY += sy - s.panStart.y;
        s.panStart = { x: sx, y: sy };
        render(); return;
      }

      const snapped = getSnap(e);
      s.mouseWorld = snapped;
      onCoordsChange(snapped.x * SCALE, snapped.y * SCALE);

      if (s.tool === 'measure' && s.points.length === 1) {
        const d = parseFloat(worldDist(s.points[0], snapped));
        onDistanceChange(d);
      }

      if (s.drawing || s.points.length > 0) render();
    }

    function onClick(e: MouseEvent) {
      if (state.current.isPanning) return;
      const s = state.current;
      const layer = layers.find(l => l.id === activeLayerId);
      if (layer?.locked) return;

      const mw = s.mouseWorld;
      const styleProps = { ...style };

      if (s.tool === 'symbol_place' && pendingSymbol) {
        onElementAdd({ type: 'symbol', x: mw.x, y: mw.y, sym: pendingSymbol.sym, label: pendingSymbol.label, layerId: activeLayerId, ...styleProps });
        onToolChange('select');
        return;
      }

      if (s.tool === 'select') {
        let found: number | null = null;
        const tol = 8 / s.zoom;
        for (let i = elements.length - 1; i >= 0; i--) {
          if (hitTest(elements[i], mw, tol)) { found = elements[i].id; break; }
        }
        onSelect(found); return;
      }

      if (s.tool === 'measure') {
        if (s.points.length === 0) { s.points = [{ ...mw }]; s.drawing = true; }
        else { s.points = []; s.drawing = false; onDistanceChange(null); }
        return;
      }

      if (s.tool === 'line') {
        if (!s.drawing) { s.points = [{ ...mw }]; s.drawing = true; }
        else {
          onElementAdd({ type: 'line', x1: s.points[0].x, y1: s.points[0].y, x2: mw.x, y2: mw.y, layerId: activeLayerId, ...styleProps });
          s.points = []; s.drawing = false;
        }
        return;
      }
      if (s.tool === 'circle') {
        if (!s.drawing) { s.points = [{ ...mw }]; s.drawing = true; }
        else {
          const c = wToS(s.points[0].x, s.points[0].y, s.panX, s.panY, s.zoom);
          const m2 = wToS(mw.x, mw.y, s.panX, s.panY, s.zoom);
          const r = dist2(c, m2) / s.zoom;
          onElementAdd({ type: 'circle', cx: s.points[0].x, cy: s.points[0].y, r, layerId: activeLayerId, ...styleProps });
          s.points = []; s.drawing = false;
        }
        return;
      }
      if (s.tool === 'rect') {
        if (!s.drawing) { s.points = [{ ...mw }]; s.drawing = true; }
        else {
          onElementAdd({ type: 'rect', x1: s.points[0].x, y1: s.points[0].y, x2: mw.x, y2: mw.y, layerId: activeLayerId, ...styleProps });
          s.points = []; s.drawing = false;
        }
        return;
      }
      if (s.tool === 'polyline' || s.tool === 'polygon') {
        s.points.push({ ...mw }); s.drawing = true; return;
      }
    }

    function onDblClick() {
      const s = state.current;
      if (s.tool === 'polyline' && s.points.length >= 2) {
        onElementAdd({ type: 'polyline', points: [...s.points], layerId: activeLayerId, ...style });
        s.points = []; s.drawing = false; render();
      } else if (s.tool === 'polygon' && s.points.length >= 3) {
        onElementAdd({ type: 'polygon', points: [...s.points], layerId: activeLayerId, ...style });
        s.points = []; s.drawing = false; render();
      }
    }

    function onWheel(e: WheelEvent) {
      e.preventDefault();
      const rect = canvas!.getBoundingClientRect();
      const mx = e.clientX - rect.left, my = e.clientY - rect.top;
      const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
      state.current.panX = mx - (mx - state.current.panX) * factor;
      state.current.panY = my - (my - state.current.panY) * factor;
      state.current.zoom = Math.max(0.1, Math.min(10, state.current.zoom * factor));
      onZoomChange(state.current.zoom);
      render();
    }

    function onMouseDown(e: MouseEvent) {
      if (e.button === 1 || (e.button === 0 && state.current.tool === 'pan')) {
        state.current.isPanning = true;
        const rect = canvas!.getBoundingClientRect();
        state.current.panStart = { x: e.clientX - rect.left, y: e.clientY - rect.top };
        canvas!.style.cursor = 'grabbing';
      }
    }

    function onMouseUp() {
      if (state.current.isPanning) {
        state.current.isPanning = false;
        state.current.panStart = null;
        canvas!.style.cursor = 'crosshair';
      }
    }

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('click', onClick);
    canvas.addEventListener('dblclick', onDblClick);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('mousedown', onMouseDown);
    canvas.addEventListener('mouseup', onMouseUp);
    return () => {
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('click', onClick);
      canvas.removeEventListener('dblclick', onDblClick);
      canvas.removeEventListener('wheel', onWheel);
      canvas.removeEventListener('mousedown', onMouseDown);
      canvas.removeEventListener('mouseup', onMouseUp);
    };
  }, [elements, layers, activeLayerId, style, pendingSymbol, onElementAdd, onSelect, onToolChange, onCoordsChange, onZoomChange, onDistanceChange, render]);

  // Resize observer
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const ro = new ResizeObserver(() => {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight - 22;
      if (state.current.panX === 0) {
        state.current.panX = canvas.width / 2;
        state.current.panY = canvas.height / 2;
      }
      render();
    });
    ro.observe(container);
    return () => ro.disconnect();
  }, [render]);

  return (
    <div ref={containerRef} style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#0d1117' }}>
      <canvas ref={canvasRef} style={{ cursor: 'crosshair', display: 'block' }} />
    </div>
  );
});

export default CADCanvas;
