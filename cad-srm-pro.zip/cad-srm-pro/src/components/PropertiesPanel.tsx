'use client';

import type { ElementStyle, DrawingElementUnion, LayerData } from '@/types';

interface Props {
  style: ElementStyle;
  onStyleChange: (style: Partial<ElementStyle>) => void;
  selectedElement: DrawingElementUnion | null;
  layers: LayerData[];
}

const SCALE = 0.5;

function getElementInfo(el: DrawingElementUnion, layers: LayerData[]) {
  const layer = layers.find(l => l.id === el.layerId);
  const info: { label: string; value: string }[] = [
    { label: 'Type', value: el.type },
    { label: 'Calque', value: layer?.name ?? '—' },
  ];
  if (el.type === 'line') {
    const dx = el.x2 - el.x1, dy = el.y2 - el.y1;
    const d = (Math.sqrt(dx * dx + dy * dy) * SCALE).toFixed(3);
    info.push({ label: 'Longueur', value: d + ' m' });
    const angle = (Math.atan2(dy, dx) * 180 / Math.PI).toFixed(1);
    info.push({ label: 'Azimut', value: angle + '°' });
  } else if (el.type === 'circle') {
    info.push({ label: 'Rayon', value: (el.r * SCALE).toFixed(3) + ' m' });
    info.push({ label: 'Périmètre', value: (2 * Math.PI * el.r * SCALE).toFixed(3) + ' m' });
    info.push({ label: 'Superficie', value: (Math.PI * el.r * el.r * SCALE * SCALE).toFixed(3) + ' m²' });
  } else if (el.type === 'rect') {
    const w = Math.abs(el.x2 - el.x1) * SCALE, h = Math.abs(el.y2 - el.y1) * SCALE;
    info.push({ label: 'Largeur', value: w.toFixed(3) + ' m' });
    info.push({ label: 'Hauteur', value: h.toFixed(3) + ' m' });
    info.push({ label: 'Superficie', value: (w * h).toFixed(3) + ' m²' });
  } else if (el.type === 'polygon' || el.type === 'polyline') {
    info.push({ label: 'Points', value: el.points.length.toString() });
  } else if (el.type === 'text') {
    info.push({ label: 'Contenu', value: el.content });
    info.push({ label: 'Taille', value: el.size + 'px' });
  }
  return info;
}

export default function PropertiesPanel({ style, onStyleChange, selectedElement, layers }: Props) {
  const label = (text: string) => (
    <div style={{ fontSize: 11, color: '#8b949e', marginBottom: 4 }}>{text}</div>
  );
  const row = (children: React.ReactNode) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
      {children}
    </div>
  );

  return (
    <div style={{ padding: 10 }}>
      <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', marginBottom: 8 }}>
        Trait
      </div>
      {row(<>
        <span style={{ fontSize: 11, color: '#8b949e' }}>Couleur</span>
        <input type="color" value={style.stroke} onChange={e => onStyleChange({ stroke: e.target.value })}
          style={{ width: 28, height: 22, borderRadius: 3, border: '1px solid #30363d', cursor: 'pointer', padding: 1, background: '#0d1117' }} />
      </>)}
      {row(<>
        <span style={{ fontSize: 11, color: '#8b949e' }}>Épaisseur</span>
        <input type="number" value={style.width} min={0.5} max={10} step={0.5}
          onChange={e => onStyleChange({ width: parseFloat(e.target.value) })}
          style={{ width: 60, background: '#0d1117', border: '1px solid #30363d', color: '#c9d1d9', borderRadius: 3, padding: '3px 6px', fontSize: 11 }} />
      </>)}

      <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', margin: '12px 0 8px' }}>
        Remplissage
      </div>
      {row(<>
        <span style={{ fontSize: 11, color: '#8b949e' }}>Couleur</span>
        <input type="color" value={style.fill} onChange={e => onStyleChange({ fill: e.target.value })}
          style={{ width: 28, height: 22, borderRadius: 3, border: '1px solid #30363d', cursor: 'pointer', padding: 1, background: '#0d1117' }} />
      </>)}
      {row(<>
        <span style={{ fontSize: 11, color: '#8b949e' }}>Opacité {style.opacity}%</span>
        <input type="range" min={0} max={100} value={style.opacity}
          onChange={e => onStyleChange({ opacity: parseInt(e.target.value) })}
          style={{ width: 80 }} />
      </>)}

      <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', margin: '12px 0 8px' }}>
        Style de ligne
      </div>
      <select
        value={style.linestyle}
        onChange={e => onStyleChange({ linestyle: e.target.value as ElementStyle['linestyle'] })}
        style={{
          width: '100%',
          background: '#0d1117',
          border: '1px solid #30363d',
          color: '#c9d1d9',
          borderRadius: 4,
          padding: '5px 8px',
          fontSize: 11,
          marginBottom: 12,
        }}
      >
        <option value="solid">Continu ───</option>
        <option value="dashed">Tirets ╌╌╌</option>
        <option value="dotted">Pointillés ···</option>
      </select>

      {selectedElement && (
        <>
          <div style={{ width: '100%', height: 1, background: '#21262d', margin: '4px 0 12px' }} />
          <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', marginBottom: 8 }}>
            Élément sélectionné
          </div>
          {getElementInfo(selectedElement, layers).map(item => (
            <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
              <span style={{ fontSize: 11, color: '#8b949e' }}>{item.label}</span>
              <span style={{ fontSize: 11, color: '#c9d1d9', fontFamily: 'monospace' }}>{item.value}</span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
