'use client';

import type { SymbolDef } from '@/types';

export const TOPO_SYMBOLS: SymbolDef[] = [
  { sym: '△', label: 'Point géod.', category: 'Géodésie' },
  { sym: '⊕', label: 'Station', category: 'Géodésie' },
  { sym: '●', label: 'Borne', category: 'Géodésie' },
  { sym: '◎', label: 'Puits', category: 'Hydraulique' },
  { sym: '⊙', label: 'Regard', category: 'Hydraulique' },
  { sym: '⊞', label: 'Repère NGF', category: 'Géodésie' },
  { sym: '✕', label: 'Croisement', category: 'Voirie' },
  { sym: '⬡', label: 'Bâtiment', category: 'Urbain' },
  { sym: '◈', label: 'Sondage', category: 'Géotechnique' },
  { sym: '⊿', label: 'Dénivelé', category: 'Topo' },
  { sym: '⊗', label: 'Arbre', category: 'Végétation' },
  { sym: '⊂', label: 'Talus', category: 'Topo' },
  { sym: '◇', label: 'Poteau él.', category: 'Réseaux' },
  { sym: '⊏', label: 'Caniv.', category: 'Hydraulique' },
  { sym: '⌖', label: 'Cible', category: 'Géodésie' },
  { sym: '⊡', label: 'Coffret', category: 'Réseaux' },
];

const CATEGORIES = [...new Set(TOPO_SYMBOLS.map(s => s.category))];

interface Props {
  onSymbolSelect: (sym: SymbolDef) => void;
  activeSymbol: string | null;
}

export default function SymbolsPanel({ onSymbolSelect, activeSymbol }: Props) {
  return (
    <div style={{ padding: 10 }}>
      {CATEGORIES.map(cat => (
        <div key={cat} style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', marginBottom: 6 }}>
            {cat}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
            {TOPO_SYMBOLS.filter(s => s.category === cat).map(s => (
              <div
                key={s.sym + s.label}
                onClick={() => onSymbolSelect(s)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 3,
                  padding: '6px 4px',
                  border: activeSymbol === s.label ? '1px solid #58a6ff' : '1px solid #30363d',
                  borderRadius: 4,
                  cursor: 'pointer',
                  background: activeSymbol === s.label ? '#0d1f3c' : '#0d1117',
                  transition: 'all 0.1s',
                }}
              >
                <span style={{ fontSize: 18, color: '#58a6ff' }}>{s.sym}</span>
                <span style={{ fontSize: 9, color: '#8b949e', textAlign: 'center', lineHeight: 1.2 }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
