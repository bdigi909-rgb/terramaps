'use client';

import { useState } from 'react';
import type { LayerData } from '@/types';

interface Props {
  layers: LayerData[];
  activeLayerId: number;
  onLayerSelect: (id: number) => void;
  onLayerToggleVisible: (id: number) => void;
  onLayerToggleLock: (id: number) => void;
  onLayerAdd: (name: string, color: string) => void;
  onLayerDelete: (id: number) => void;
}

const LAYER_COLORS = ['#58a6ff', '#3fb950', '#e3b341', '#a371f7', '#f85149', '#39d353', '#ff7b72', '#ffa657'];

export default function LayersPanel({
  layers, activeLayerId, onLayerSelect,
  onLayerToggleVisible, onLayerToggleLock,
  onLayerAdd, onLayerDelete,
}: Props) {
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState('#58a6ff');

  function handleAdd() {
    if (!newName.trim()) return;
    onLayerAdd(newName.trim(), newColor);
    setNewName(''); setNewColor('#58a6ff'); setAdding(false);
  }

  return (
    <div style={{ padding: 10 }}>
      <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#8b949e', marginBottom: 8 }}>
        Calques du projet
      </div>

      {layers.map(layer => (
        <div
          key={layer.id}
          onClick={() => onLayerSelect(layer.id)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '5px 6px',
            borderRadius: 4,
            cursor: 'pointer',
            marginBottom: 2,
            background: layer.id === activeLayerId ? '#0d1117' : 'transparent',
            border: layer.id === activeLayerId ? '1px solid #30363d' : '1px solid transparent',
          }}
        >
          <div style={{
            width: 10,
            height: 10,
            borderRadius: 2,
            background: layer.color,
            flexShrink: 0,
            opacity: layer.visible ? 1 : 0.3,
          }} />
          <span style={{
            flex: 1,
            fontSize: 11,
            color: layer.visible ? '#c9d1d9' : '#484f58',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {layer.name}
          </span>
          <span
            title="Visibilité"
            onClick={e => { e.stopPropagation(); onLayerToggleVisible(layer.id); }}
            style={{ fontSize: 12, color: layer.visible ? '#8b949e' : '#484f58', cursor: 'pointer' }}
          >
            {layer.visible ? '👁' : '🙈'}
          </span>
          <span
            title="Verrouillage"
            onClick={e => { e.stopPropagation(); onLayerToggleLock(layer.id); }}
            style={{ fontSize: 11, color: layer.locked ? '#e3b341' : '#484f58', cursor: 'pointer' }}
          >
            {layer.locked ? '🔒' : '🔓'}
          </span>
          {layers.length > 1 && (
            <span
              title="Supprimer le calque"
              onClick={e => { e.stopPropagation(); onLayerDelete(layer.id); }}
              style={{ fontSize: 11, color: '#484f58', cursor: 'pointer' }}
            >
              ✕
            </span>
          )}
        </div>
      ))}

      {adding ? (
        <div style={{ marginTop: 8, padding: '8px', background: '#0d1117', borderRadius: 6, border: '1px solid #30363d' }}>
          <input
            autoFocus
            value={newName}
            onChange={e => setNewName(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') handleAdd(); if (e.key === 'Escape') setAdding(false); }}
            placeholder="Nom du calque"
            style={{
              width: '100%',
              background: 'transparent',
              border: 'none',
              borderBottom: '1px solid #30363d',
              color: '#c9d1d9',
              fontSize: 11,
              padding: '4px 0',
              outline: 'none',
              marginBottom: 8,
            }}
          />
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 8 }}>
            {LAYER_COLORS.map(c => (
              <div
                key={c}
                onClick={() => setNewColor(c)}
                style={{
                  width: 16,
                  height: 16,
                  borderRadius: 3,
                  background: c,
                  cursor: 'pointer',
                  border: newColor === c ? '2px solid #fff' : '2px solid transparent',
                }}
              />
            ))}
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={() => setAdding(false)} style={{ flex: 1, padding: '4px', background: 'transparent', border: '1px solid #30363d', borderRadius: 4, color: '#8b949e', cursor: 'pointer', fontSize: 11 }}>
              Annuler
            </button>
            <button onClick={handleAdd} style={{ flex: 1, padding: '4px', background: '#238636', border: 'none', borderRadius: 4, color: '#fff', cursor: 'pointer', fontSize: 11 }}>
              Créer
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setAdding(true)}
          style={{
            width: '100%',
            padding: 6,
            background: 'transparent',
            border: '1px dashed #30363d',
            borderRadius: 4,
            color: '#8b949e',
            cursor: 'pointer',
            fontSize: 11,
            marginTop: 6,
          }}
        >
          + Nouveau calque
        </button>
      )}
    </div>
  );
}
