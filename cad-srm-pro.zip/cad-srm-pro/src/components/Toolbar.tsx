'use client';

import type { DrawingTool } from '@/types';

interface Props {
  tool: DrawingTool;
  onToolChange: (tool: DrawingTool) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomFit: () => void;
  onUndo: () => void;
  onDelete: () => void;
}

const tools: { id: DrawingTool; icon: string; label: string; shortcut: string }[] = [
  { id: 'select', icon: '↖', label: 'Sélection', shortcut: 'Esc' },
  { id: 'line', icon: '╱', label: 'Ligne', shortcut: 'L' },
  { id: 'polyline', icon: '⌇', label: 'Polyligne', shortcut: 'P' },
  { id: 'polygon', icon: '⬟', label: 'Polygone', shortcut: 'G' },
  { id: 'circle', icon: '○', label: 'Cercle', shortcut: 'C' },
  { id: 'rect', icon: '▭', label: 'Rectangle', shortcut: 'R' },
  { id: 'text', icon: 'T', label: 'Texte', shortcut: 'T' },
  { id: 'measure', icon: '⟷', label: 'Mesure', shortcut: 'M' },
  { id: 'pan', icon: '✥', label: 'Panoramique', shortcut: 'Espace' },
];

export default function Toolbar({ tool, onToolChange, onZoomIn, onZoomOut, onZoomFit, onUndo, onDelete }: Props) {
  const btnStyle = (active: boolean, danger = false): React.CSSProperties => ({
    width: 32,
    height: 32,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 4,
    cursor: 'pointer',
    color: danger ? '#f85149' : active ? '#58a6ff' : '#8b949e',
    background: active ? '#0d1117' : 'transparent',
    border: active ? '1px solid #1f6feb' : '1px solid transparent',
    fontSize: 16,
    fontFamily: 'monospace',
    transition: 'all 0.1s',
    userSelect: 'none',
  });

  return (
    <div style={{
      width: 44,
      background: '#161b22',
      borderRight: '1px solid #30363d',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '8px 0',
      gap: 2,
    }}>
      {tools.map((t, i) => (
        <>
          {(i === 1 || i === 7) && (
            <div key={`sep-${i}`} style={{ width: 24, height: 1, background: '#30363d', margin: '4px 0' }} />
          )}
          <div
            key={t.id}
            title={`${t.label} (${t.shortcut})`}
            style={btnStyle(tool === t.id)}
            onClick={() => onToolChange(t.id)}
          >
            {t.icon}
          </div>
        </>
      ))}

      <div style={{ width: 24, height: 1, background: '#30363d', margin: '4px 0' }} />
      <div title="Zoom +" style={btnStyle(false)} onClick={onZoomIn}>+</div>
      <div title="Zoom −" style={btnStyle(false)} onClick={onZoomOut}>−</div>
      <div title="Ajuster la vue" style={btnStyle(false)} onClick={onZoomFit}>⊡</div>

      <div style={{ width: 24, height: 1, background: '#30363d', margin: '4px 0' }} />
      <div title="Annuler (Ctrl+Z)" style={btnStyle(false)} onClick={onUndo}>↩</div>
      <div title="Supprimer (Del)" style={btnStyle(false, true)} onClick={onDelete}>✕</div>
    </div>
  );
}
