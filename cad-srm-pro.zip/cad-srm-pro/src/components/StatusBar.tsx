'use client';

import type { DrawingTool } from '@/types';

interface Props {
  coordX: number;
  coordY: number;
  zoom: number;
  elementCount: number;
  tool: DrawingTool;
  distance: number | null;
  activeLayerName: string;
  gridSize: number;
}

const TOOL_HINTS: Record<string, string> = {
  select: 'Cliquer pour sélectionner — Del pour supprimer',
  line: '1er clic : départ — 2e clic : arrivée',
  polyline: 'Clics pour ajouter des points — double-clic pour terminer',
  polygon: 'Clics pour ajouter des sommets — double-clic pour fermer',
  circle: '1er clic : centre — 2e clic : rayon',
  rect: '1er clic : coin 1 — 2e clic : coin 2',
  text: 'Cliquer pour placer le texte',
  measure: '1er clic : départ — 2e clic : réinitialiser',
  pan: 'Clic-glisser pour déplacer la vue',
  symbol_place: 'Cliquer pour placer le symbole',
};

export default function StatusBar({ coordX, coordY, zoom, elementCount, tool, distance, activeLayerName, gridSize }: Props) {
  return (
    <div style={{
      height: 24,
      background: '#161b22',
      borderTop: '1px solid #30363d',
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '0 12px',
      fontSize: 11,
      color: '#8b949e',
      flexShrink: 0,
    }}>
      <span>X: <span style={{ color: '#58a6ff', fontFamily: 'monospace' }}>{coordX.toFixed(3)}</span></span>
      <span>Y: <span style={{ color: '#58a6ff', fontFamily: 'monospace' }}>{coordY.toFixed(3)}</span></span>
      {distance !== null && (
        <span>Dist: <span style={{ color: '#e3b341', fontFamily: 'monospace' }}>{distance.toFixed(3)} m</span></span>
      )}
      <span>Zoom: <span style={{ color: '#58a6ff', fontFamily: 'monospace' }}>{Math.round(zoom * 100)}%</span></span>
      <span style={{ marginLeft: 'auto' }}>{TOOL_HINTS[tool] ?? ''}</span>
      <span>Calque: <span style={{ color: '#3fb950' }}>{activeLayerName}</span></span>
      <span>Grille: <span style={{ color: '#58a6ff' }}>{gridSize} m</span></span>
      <span>Éléments: <span style={{ color: '#58a6ff' }}>{elementCount}</span></span>
    </div>
  );
}
