export type DrawingTool =
  | 'select'
  | 'line'
  | 'polyline'
  | 'polygon'
  | 'circle'
  | 'rect'
  | 'text'
  | 'measure'
  | 'pan'
  | 'symbol_place';

export type LineStyle = 'solid' | 'dashed' | 'dotted';

export interface Point {
  x: number;
  y: number;
}

export interface ElementStyle {
  stroke: string;
  fill: string;
  width: number;
  opacity: number;
  linestyle: LineStyle;
}

export interface BaseElement extends ElementStyle {
  id: number;
  layerId: number;
  type: string;
}

export interface LineElement extends BaseElement {
  type: 'line';
  x1: number; y1: number;
  x2: number; y2: number;
}

export interface PolylineElement extends BaseElement {
  type: 'polyline';
  points: Point[];
}

export interface PolygonElement extends BaseElement {
  type: 'polygon';
  points: Point[];
}

export interface CircleElement extends BaseElement {
  type: 'circle';
  cx: number; cy: number;
  r: number;
}

export interface RectElement extends BaseElement {
  type: 'rect';
  x1: number; y1: number;
  x2: number; y2: number;
}

export interface TextElement extends BaseElement {
  type: 'text';
  x: number; y: number;
  content: string;
  size: number;
}

export interface SymbolElement extends BaseElement {
  type: 'symbol';
  x: number; y: number;
  sym: string;
  label: string;
}

export type DrawingElementUnion =
  | LineElement
  | PolylineElement
  | PolygonElement
  | CircleElement
  | RectElement
  | TextElement
  | SymbolElement;

export interface LayerData {
  id: number;
  name: string;
  color: string;
  visible: boolean;
  locked: boolean;
  order: number;
}

export interface ProjectSettings {
  units: 'meters' | 'feet';
  gridSize: number;
  coordinateSystem: string;
  scale: number;
}

export interface ProjectData {
  id: number;
  name: string;
  description?: string | null;
  settings: ProjectSettings;
  createdAt: string;
  updatedAt: string;
}

export interface SymbolDef {
  sym: string;
  label: string;
  category: string;
}
